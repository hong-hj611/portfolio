'use client'
import React from 'react'

const Node = () => {
  return (
    <div style={{textAlign:'center', marginTop: 50}}>
      <h2>Node.js + GCP + DB 로 구현한 방명록</h2>
      <iframe src="https://guestbook-563543993385.us-central1.run.app/" style={{width: '100%', height: '100vh', marginTop:30}} ></iframe>
    </div>
  )
}

export default Node