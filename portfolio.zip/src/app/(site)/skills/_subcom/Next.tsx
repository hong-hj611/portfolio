'use client'
import React from 'react'

const Next = () => {
  return (
    <div>Next</div>
  )
}

export default Next