import React from 'react'

const page = () => {
  return (
    <section>
      contact
    </section>
  )
}

export default page