'use client'
import React, { useEffect, useRef } from 'react'
// import CanvasParticle from '../com/CanvasParticle'
import IntroText from '../com/IntroText'

const page = () => { 

  return (
    <section>
      {/* <CanvasParticle /> */}
      <IntroText />
    </section>
  )
}

export default page